#include <iostream>
#include <fstream>
#include <istream>
#include <string>
#include <cstring>

using namespace std;

// TO DO 
// write these three functions:
int vocabularyCreator(istream& dictfile, string dict[]);
int potentialSequences(string word, const string dict[], int size, string results[]);
void outcomeDisclosure(const string results[], int size);



const int MAXRESULTS   = 20;    // Max matches that can be found
const int MAXDICTWORDS = 30000; // Max words that can be read in

// words ~25k
// words3: 6
// words4: 200
// words5 1k // still works
// words6 2.2k // still works -> at 2.2k words, we use 1,201,124 bytes -> which means at ~15k we stack overflow
// words7 50k words.... breaks

int main()
{
    string results[MAXRESULTS];
    string dict[MAXDICTWORDS];
    ifstream dictfile;         // file containing the list of words
    int nwords;                // number of words read from dictionary
    string word;

    dictfile.open("words.txt");
    if (!dictfile)
    {
        cout << "File not found!" << endl;
        
    }
    else 
    {
        cout << "File found!" << endl;
 
    }

       nwords = vocabularyCreator(dictfile, dict);


       cout << "The Length of the Array is : " << end(dict) - begin(dict)<< endl;

       int counter = 0;
       for (int i =0; i< 30000; i++)
    {
           if (!dict[i].empty())
           {
               counter++;
               cout << dict[i] << " ";
           }
    }
       cout<< endl;
       //cout << counter << endl;
       cout << nwords << endl;

 //   cout << "Please enter a string for an anagram: ";
 //   cin >> word;

 //   int numMatches = potentialSequences(word, dict, nwords, results);
 //   if (!numMatches) {
 //       cout << "No matches found" << endl;
	//}
 //   else {
 //       outcomeDisclosure(results, numMatches);
	//}

	return 0;
}

//
//int vocabularyCreator(istream& dictfile, string dict[])
//{
//    
//        string word;
//        dictfile >> word;
//
//        if (dictfile.peek() == EOF || dictfile.tellg() >= MAXDICTWORDS) 
//        {
//            if (!word.empty()) 
//            {
//                dict[0] = word;
//                return 1; // only here would the base case be init, set count to 1, else it was uninitialized
//            }
//            return 0;
//        }
//
//        int numWords = vocabularyCreator(dictfile, dict);
//
//        if (numWords < MAXDICTWORDS && !word.empty()) 
//        {
//            dict[numWords] = word;
//            return numWords + 1;
//        }
//
//        return numWords;
//    
//
//}




//int vocabularyCreator(istream& dictfile, string dict[]) 
// {
//    string word;
//    dictfile >> word;
//
//    // Base case: If the word read is empty or the maximum number of data entries is reached
//    if (word.empty() || dictfile.peek() == EOF || dictfile.tellg() >= MAXDICTWORDS) {
//        if (!word.empty()) {
//            dict[0] = word;
//            return 1; // Return 1 since we have one word stored in the array
//        }
//        return 0; // Return 0 since no words were stored in the array
//    }
//
//    // Recursively call the function to process the next word
//    int numWords = vocabularyCreator(dictfile, dict + 1); // Pass the next index in the array
//
//    // Store the word in the dict array at the current index
//    dict[0] = word;
//
//    return numWords + 1; // Return the total number of words read
//}
//
//int vocabularyCreator(istream& dictfile, string dict[]) 
// {
//     //Read a word from the dictfile
//    string word;
//    dictfile >> word;
//
//     //Check if the word read is empty (end of file or delimiter)
//    if (word.empty() || dictfile.peek() == EOF || dictfile.tellg() >= MAXDICTWORDS) 
//    {
//        return 0;
//    }
//
//    // Recursively call the function to process the next word
//    int numWords = vocabularyCreator(dictfile, dict);
//
//     //Store the word in the dict array at the current index
//    dict[numWords] = word;
//
//    return numWords + 1; // Return the total number of words read
//}


 //this approach still overflows....
 //~14 MB

//int vocabularyCreator(istream& dictfile, string dict[])
//{
//    string word;
//
//    // continuously puts in the word until the limit is reached (MAXDICTWORDS) OR if at end of file
//    // the problem is that if number of words inputted is > MAXDICTION counter wraps around
//
//    if (dictfile >> word) 
//    {
//        // at end of the file, no more files can be placed in so vocab creator will be set to zero
//        // then we can start to recurse backwards
//        int wordCount = vocabularyCreator(dictfile, dict);
// 
//        
//        if (wordCount < MAXDICTWORDS) 
//        {
//            dict[wordCount] = word;
//            return wordCount + 1;
//        }
//
//    }
//
//    // base case is if we can't put anymore words in
//    // we should be able to reach here if max number of words is already put into the array
//    return 0;
//}

 //~12MB


int vocabularyCreator(istream& dictfile, string dict[])
{
    int counter = 0;


    if (counter > MAXDICTWORDS)
        return counter;

    // similarly using successful input as recursive condition
    if (getline(dictfile, dict[0]))
    {
        counter++;
        return counter += vocabularyCreator(dictfile, dict + 1);
    }


    else
        return counter;
}

//int readWordsFromFileHelper(std::istream& dictfile, std::string dict[], int counter) {
//    if (counter >= MAXDICTWORDS || !getline(dictfile, dict[counter])) {
//        return counter;
//    }
//
//    return readWordsFromFileHelper(dictfile, dict, counter + 1);
//}
//
//int vocabularyCreator(std::istream& dictfile, std::string dict[]) {
//    return readWordsFromFileHelper(dictfile, dict, 0);
//}

//
//int vocabularyCreator(istream& dictfile, string dict[])
//{
//    int counter = 0;
//    string word;
//
//    if (dictfile.eof())
//        return 0;
//    if (counter > MAXDICTWORDS)
//        return counter;
//
//    // similarly using successful input as recursive condition
//
//    if (dictfile >> word)
//    {
//        *dict = word;
//        counter++;
//        return counter += vocabularyCreator(dictfile, dict + 1);
//    }
//
//
//    else
//        return counter;
//}

// ~15MB
//int vocabularyCreator(istream& dictfile, string dict[]) 
//{
//
//    string word;
//
//    if (dictfile.eof())
//        return 0;
//
//    dictfile >> word;
//        
//    int x = vocabularyCreator(dictfile, dict);
//
//    if (x < MAXDICTWORDS) 
//    {
//        // dict[x] = word;
//        *dict = word;
//        dict++;
//        x++;
//        return x;
//    }
//
//    else
//
//        return MAXDICTWORDS;
//
//}


int potentialSequences(string word, const string dict[], int size, string results[]) { return 0; }